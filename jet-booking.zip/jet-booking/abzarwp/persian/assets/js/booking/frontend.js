(() => {
  'use strict';
  const t = 'YYYY-MM-DD',
    { InputData: e } = JetFormBuilderAbstract,
    { isEmpty: n } = JetFormBuilderFunctions,
    { field_format: i = t, layout: o = 'single' } = window?.JetABAFInput ?? {},
    { per_nights: r, one_day_bookings: a } = window?.JetABAFData ?? {};
  function u() {
    e.call(this),
      this.sanitize(function (e) {
        return n(e) || (!Array.isArray(e) && 'string' != typeof e)
          ? []
          : Array.isArray(e)
          ? e
          : (e = e.split(' - ')).length
          ? e.map((e) => e)
          : [];
      }),
      (this.isSupported = function (t) {
        return 'checkin-checkout' === t.dataset.field;
      }),
      (this.addListeners = function () {
        (this.reporting.makeInvalid = () => {}),
          (this.reporting.makeValid = () => {});
        const [t] = this.nodes;
        jQuery(t).on('change.JetFormBuilderMain', () => {
          let o, i;
          o = t.value;
          i = jQuery(this.callable.input.nodes);
          this.isMaked = true;
          this.value.current = o;
          i.val(o);
        });
        const e = t.parentElement.querySelectorAll('.jet-abaf-field__input');
        for (const t of e)
          t.addEventListener('blur', () => this.reportOnBlur());
      }),
      (this.setValue = function () {
        this.value.current = this.value.applySanitizers(this.nodes[0].value);
      }),
      (this.checkIsRequired = function () {
        const [t] = this.nodes;
        return (
          !!t.required ||
          !!t.parentElement.querySelector('.jet-abaf-field__input[required]')
        );
      }),
      (this.setNode = function (t) {
        if (
          (e.prototype.setNode.call(this, t),
          (this.inputType = 'checkin-checkout'),
          'single' === o)
        )
          return;
        const n = t.closest('.jet-abaf-separate-fields');
        this.nodes.push(
          ...n.querySelectorAll('.jet-abaf-field__input[type="text"]'),
          n
        );
      });
  }
  (u.prototype = Object.create(e.prototype)),
    (u.prototype.parseValueForCalculated = function () {
      if (!this.getValue()?.length) return 0;
      if (window?.JetBooking?.calcBookedDates) {
        const e = this.getValue().map((e) => moment(e, t).format(i));
        return JetBooking.calcBookedDates(e.join(' - '));
      }
      if (a) return 1;
      const e = this.value.current.map((t) => moment(t));
      let n = e[1].diff(e[0], 'days');
      return (n = Number(n)), r || n++, n;
    });
  const s = u,
    { BaseSignal: l } = JetFormBuilderAbstract,
    { layout: c = 'single', field_format: d = t } = window.JetABAFInput;
  function p() {
    l.call(this),
      (this.isSupported = function (t, e) {
        return e instanceof s;
      }),
      (this.runSignal = function (t) {
        'single' === c
          ? this.runSignalForSingle()
          : this.runSignalForSeparate(t);
      }),
      (this.runSignalForSingle = function () {
        const [e] = this.input.nodes,
          { current: n } = this.input.value;
        n.length
          ? (e.value = n.map((e) => moment(e, t).format(d)).join(' - '))
          : (e.value = '');
      }),
      (this.runSignalForSeparate = function (e) {
        const [, n, i] = this.input.nodes,
          { current: o } = this.input.value;
        if (o?.toString?.() !== e?.toString?.()) {
          if (!o.length)
            return (n.value = ''), (i.value = ''), void this.updateCalendar();
          (n.value = moment(o[0], t).format(d)),
            (i.value = moment(o[1] ?? o[0], t).format(d)),
            this.updateCalendar();
        }
      }),
      (this.updateCalendar = function () {
        const { current: t } = this.input.value,
          [, , , e] = this.input.nodes;
        t.length
          ? jQuery(e)
              .data('dateRangePicker')
              .setDateRange(t[0], t[1] ?? t[0], !0)
          : jQuery(e).data('dateRangePicker').clear();
      });
  }
  p.prototype = Object.create(l.prototype);
  const f = p,
    { addAction: h, addFilter: m } = JetPlugins.hooks;
  h(
    'jet.fb.observe.before',
    'jet-form-builder/booking-compatibility',
    function (t) {
      const { rootNode: e } = t;
      for (const t of e.querySelectorAll('.field-type-check-in-out')) {
        const e = t.querySelector('input[data-field="checkin-checkout"]');
        e && (e.dataset.jfbSync = 1);
      }
    }
  ),
    m('jet.fb.inputs', 'jet-form-builder/booking-compatibility', function (t) {
      return [s, ...t];
    }),
    m('jet.fb.signals', 'jet-form-builder/booking-compatibility', function (t) {
      return [f, ...t];
    });
  const g = [];
  m(
    'jet.fb.onCalculate.part',
    'jet-form-builder/booking-compatibility',
    function (t, e) {
      const n = t.match(/ADVANCED_PRICE::([\w\-]+)/);
      if (!n?.length || !e?.input) return t;
      const [, i] = n,
        o = e.input.root.getInput(i);
      if (!o) return 0;
      const r = e.input.getSubmit().getFormId();
      return (
        g.includes(r + o.name) ||
          (g.push(r + o.name), o.watch(() => e.setResult())),
        t
      );
    }
  ),
    m(
      'jet.fb.calculated.callback',
      'jet-form-builder/booking-field-parser',
      function (t, e, n) {
        return !1 !== t || 'checkin-checkout' !== e.inputType
          ? t
          : e.parseValueForCalculated();
      }
    );
})();
