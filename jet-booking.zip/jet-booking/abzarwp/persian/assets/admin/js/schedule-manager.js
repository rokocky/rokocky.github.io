(function () {
  'use strict';

  Vue.use(VuePersianDatetimePicker, {
    name: 'date-picker',
    props: {
      format: 'YYYY-MM-DD',
      displayFormat: 'jYYYY-jMM-jDD', 
      autoSubmit: true,
      clearable: true,
    },
  });

  window.scheduleManager = {
    data: function () {
      return {
        editDay: false,
        date: '',
        date_object: {
          start: null,
          startTimeStamp: null,
          end: null,
          endTimeStamp: null,
          name: null,
          type: null,
          editIndex: null,
        },
        deleteDayTrigger: null,
        datePickerFormat: 'YYYY-MM-DD',
        //#abzarwp
        dateMomentFormat: 'YYYY-MM-DD',
        disabledDate: [],
      };
    },
    computed: {
      disabledDaysStatusLabel() {
        const daysList = this.getDaysList('disable');
        let label = 'Any day available for selection.';

        if (daysList.length) {
          label = daysList.join(', ') + ' completely disabled for selection.';
        }

        return wp.i18n.__(label, 'jet-booking');
      },
    },
    components: {
      vuejsDatepicker: VuePersianDatetimePicker,
    },
    methods: {
      prepareDaysOff: function () {
        for (let index = 0; index < settings.days_off; index++) {
          settings.days_off[index].start = moment(
            settings.days_off[index].start
          )
            .locale('fa')
            .format(this.dateMomentFormat);
          settings.days_off[index].end = moment(settings.days_off[index].end)
            .locale('fa')
            .format(this.dateMomentFormat);
        }
      },
      getDaysList: function (type) {
        let list = [];

        if (this.settings[type + '_weekday_1']) {
          list.push('Monday');
        }

        if (this.settings[type + '_weekday_2']) {
          list.push('Tuesday');
        }

        if (this.settings[type + '_weekday_3']) {
          list.push('Wednesday');
        }

        if (this.settings[type + '_weekday_4']) {
          list.push('Thursday');
        }

        if (this.settings[type + '_weekday_5']) {
          list.push('Friday');
        }

        if (this.settings[type + '_weekend_1']) {
          list.push('Saturday');
        }

        if (this.settings[type + '_weekend_2']) {
          list.push('Sunday');
        }

        return list;
      },

      checkInOutDaysStatusLabel(type) {
        const disabledDaysList = this.getDaysList('disable');

        if (7 === disabledDaysList.length) {
          return wp.i18n.__(
            'No available days for check ' + type + '.',
            'jet-booking'
          );
        }

        let label = 'Guests can check ' + type + ' any day.';
        let daysList = this.getDaysList('check_' + type);

        daysList = daysList.filter(
          (day) => -1 === disabledDaysList.indexOf(day)
        );

        if (daysList.length) {
          label =
            daysList.join(', ') +
            ' ' +
            wp.i18n._n('is', 'are', daysList.length, 'jet-booking') +
            ' available for check ' +
            type +
            '.';
        } else if (disabledDaysList.length) {
          label = 'Guests can check ' + type + ' any available day.';
        }

        return wp.i18n.__(label, 'jet-booking');
      },

      showEditDay: function (daysType = false, date = false) {
        if (date && daysType) {
          let index = this.settings[daysType].indexOf(date);

          this.date_object = Object.assign({}, date);
          this.date_object.editIndex = index;
          // this.date = date;
        }

        this.updateDisabledDates(daysType, date);

        this.date_object.type = daysType;
        this.editDay = true;
      },

      updateDisabledDates: function (daysType = false, excludedDate = false) {
        let newDisabledDates = [],
          _excludedDate = JSON.stringify(excludedDate);

        for (let date in this.settings[daysType]) {
          if (this.settings[daysType].hasOwnProperty(date)) {
            if (
              JSON.stringify(this.settings[daysType][date]) === _excludedDate
            ) {
              continue;
            }

            let daysFrom = moment
                .unix(this.settings[daysType][date].startTimeStamp)
                .utc(),
              toFrom = moment
                .unix(this.settings[daysType][date].endTimeStamp)
                .utc()
                .add(1, 'days');

            if (excludedDate) {
              daysFrom.add(-1, 'days');
            }
            let ranges = this.getDateRange(daysFrom, toFrom);
            newDisabledDates = ranges.concat(newDisabledDates, ranges);
          }
        }
        newDisabledDates = newDisabledDates.filter(
          (value, index, self) => self.indexOf(value) === index
        );
        this.disabledDate = '[' + newDisabledDates.join(',') + ']';
      },

      handleDayCancel: function () {
        for (let key in this.date_object) {
          if (this.date_object.hasOwnProperty(key)) {
            this.$set(this.date_object, key, null);
          }
        }

        this.editDay = false;
      },

      handleDayOk: function () {
        if (!this.date_object.endTimeStamp) {
          this.date_object.endTimeStamp = this.date_object.startTimeStamp;
        }

        if (
          !this.date_object.start ||
          this.date_object.startTimeStamp > this.date_object.endTimeStamp
        ) {
          this.$CXNotice.add({
            message: wp.i18n.__('Date is not correct', 'jet-booking'),
            type: 'error',
            duration: 7000,
          });

          return;
        }

        let date = Object.assign({}, this.date_object),
          dates = this.settings[date.type] || [],
          index = null !== date.editIndex ? date.editIndex : dates.length;

        this.$set(dates, index, date);

        for (const key in dates) {
          dates[key].start = moment(dates[key].start)
            .locale('eng')
            .format(this.dateMomentFormat);
          dates[key].end = moment(dates[key].end)
            .locale('eng')
            .format(this.dateMomentFormat);
        }

        this.updateSetting(dates, date.type);
        this.handleDayCancel();
      },

      selectedDate: function (date, daysType) {
        date = date._i;
        let dateTimestamp = this.objectDateToTimestamp(date),
          formattedDate = this.parseDate(date, this.dateMomentFormat);

        this.$set(this.date_object, daysType, formattedDate);
        this.$set(this.date_object, `${daysType}TimeStamp`, dateTimestamp);
      },

      confirmDeleteDay: function (dateObject) {
        this.deleteDayTrigger = dateObject;
      },

      deleteDay: function (daysType = false, date = false) {
        let index = this.settings[daysType].indexOf(date);

        this.$delete(this.settings[daysType], index);

        this.deleteDayTrigger = null;

        this.$nextTick(function () {
          this.saveSettings();
        });
      },
      gToj: function (timestamp) {
        if (timestamp != undefined) {
          return moment
            .unix(timestamp)
            .locale('fa')
            .format('dddd DD MMMM YYYY');
        }
        return timestamp;
      },
      getDisabledDate() {
        return this.disabledDate;
      },
      getDateRange(startDate, endDate) {
        const dates = [];
        const momentStartDate = moment(startDate);
        const momentEndDate = moment(endDate);

        // Check if start date is before or equal to end date
        if (momentStartDate.isSameOrBefore(momentEndDate)) {
          let currentDate = momentStartDate;
          while (currentDate.isSameOrBefore(momentEndDate)) {
            dates.push(currentDate.locale('fa').format('YYYY-MM-DD')); // Adjust format as needed
            currentDate.add(1, 'days'); // Increment by 1 day
          }
        } else {
          return [];
        }

        return dates;
      },
    },
  };
})();
